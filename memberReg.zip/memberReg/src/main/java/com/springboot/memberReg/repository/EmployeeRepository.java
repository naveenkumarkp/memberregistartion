package com.springboot.memberReg.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.memberReg.model.Regsitration;

@Repository
public interface EmployeeRepository extends JpaRepository<Regsitration, Long>{

	public Regsitration findByEmailId(String email);
	public Regsitration findByEmailIdAndPassword(String email, String password);

}

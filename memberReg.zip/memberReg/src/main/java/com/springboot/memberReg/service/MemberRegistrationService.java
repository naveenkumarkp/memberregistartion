package com.springboot.memberReg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.memberReg.model.Regsitration;
import com.springboot.memberReg.repository.EmployeeRepository;

@Service
public class MemberRegistrationService {

	@Autowired
	private EmployeeRepository reg;
	
	public Regsitration saveMember(Regsitration user) {
		return reg.save(user);
	}
	
	public Regsitration fetchUserByEmailId(String email) {
	  return reg.findByEmailId(email);	
	}
	
	public Regsitration fetchUserByEmailIdAndPassword(String email, String password) {
		  return reg.findByEmailIdAndPassword(email, password);	
		}
		
}


package com.springboot.memberReg.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.memberReg.exception.ResourceNotFoundException;
import com.springboot.memberReg.model.Regsitration;
import com.springboot.memberReg.repository.EmployeeRepository;
import com.springboot.memberReg.service.MemberRegistrationService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private MemberRegistrationService service;
	
	@GetMapping("/employees")
	public List<Regsitration> getAllEmployees(){
		return employeeRepository.findAll();
	}		
	
	@PostMapping("/employees")
	public String saveRegsitration(@RequestBody Regsitration details) {
		employeeRepository.save(details);
		return "Added new Member with id : " + details.getId();
	}
	
	@GetMapping("/employees/{id}")
	public ResponseEntity<Regsitration> getMemberById(@PathVariable Long id) {
		Regsitration employee = employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Regsitration not exist with id :" + id));
		return ResponseEntity.ok(employee);
	}
	
	
	@PutMapping("/employees/{id}")
	public ResponseEntity<Regsitration> updateMember(@PathVariable Long id, @RequestBody Regsitration employeeDetails){
		Regsitration employee = employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Member not exist with id :" + id));
		System.out.println(employeeDetails.getPancardno());
		employee.setFirstName(employeeDetails.getFirstName());
		employee.setLastName(employeeDetails.getLastName());
		employee.setEmailId(employeeDetails.getEmailId());
		employee.setPassword(employeeDetails.getPassword());
		employee.setPancardno(employeeDetails.getPancardno());
		employee.setPhoneno(employeeDetails.getPhoneno());
		employee.setAge(employeeDetails.getAge()); 
		employee.setAddress(employeeDetails.getAddress());
		
		Regsitration updatedEmployee = employeeRepository.save(employee);
		return ResponseEntity.ok(updatedEmployee);
	}
	
	@DeleteMapping("/employees/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id){
		Regsitration employee = employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		
		employeeRepository.delete(employee);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/login/{emailId}/{passWord}")
	public ResponseEntity<Regsitration> loginMember(@PathVariable String emailId,@PathVariable String passWord) throws Exception {
		String tempEmailId = emailId;
		String password = passWord;
		Regsitration userObj = null;
		System.out.println(tempEmailId+"  "+password);
		if(tempEmailId != null && password != null) {
			userObj = service.fetchUserByEmailIdAndPassword(tempEmailId, password);
		}
		if(userObj == null) {
			throw new Exception("User Id Doesn't exist");
		}
		return ResponseEntity.ok(userObj);
	}
}
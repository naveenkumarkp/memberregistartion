package com.springboot.memberReg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemberRegApplicationTests {

	@Test
	void contextLoads() {
	}

}
